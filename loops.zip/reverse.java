//WAP to display the series from 10 to 1 in reverse order.//
class reverse
{
public static void main(String []args)
{
int n=10;
System.out.println("reverse order from 10");
for(int i=n; i>=1; i--)
{
System.out.println(i);
}
}
}