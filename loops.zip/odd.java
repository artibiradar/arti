 //WAP to display first 100 odd numbers.//
class odd
{
public static void main(String []args)
{
int i;
for(i=1;i<=100;i++)
{
if(i%2!=0)
{
System.out.println(i);
}
}
}
}