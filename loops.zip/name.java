
//WAP to display your name 5 times on screen.//

class name
{
public static void main(String[]args)
{
for(int i=0;i<5;i++)
System.out.println("Kiran");
}
}
